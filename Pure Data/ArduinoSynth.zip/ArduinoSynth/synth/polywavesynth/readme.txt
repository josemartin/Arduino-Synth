This is version 4.0 of [polywavesynth], a free and freely distributable synthesizer for Pd (Pure Data).

See http://www.pkstonemusic.com/polyWaveSynth.html for complete documentation.

Run polywavesynth_example.pd to get instant gratifcation.